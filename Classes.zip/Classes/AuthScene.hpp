//
//  AuthScene.hpp
//  UmengGame
//
//  Created by wangfei on 16/4/6.
//
//

#ifndef AuthScene_hpp
#define AuthScene_hpp

#include <stdio.h>

#endif /* AuthScene_hpp */
