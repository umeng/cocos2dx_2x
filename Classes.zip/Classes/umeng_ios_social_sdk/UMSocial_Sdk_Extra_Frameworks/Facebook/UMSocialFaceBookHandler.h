//
//  UMSocialFacebookHandler.h
//  UMSocialSDK
//
//  Created by wyq.Cloudayc on 8/18/16.
//  Copyright © 2016 dongjianxiong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UMSocialCore/UMSocialCore.h>

@interface UMSocialFacebookHandler : UMSocialHandler

@end
