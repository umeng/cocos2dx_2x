//
//  UMSocialRenrenHandler.h
//  SocialSDK
//
//  Created by umeng on 16/4/23.
//  Copyright © 2016年 dongjianxiong. All rights reserved.
//

#import <UMSocialCore/UMSocialCore.h>

@interface UMSocialRenrenHandler : UMSocialHandler

@end
